## Off-canvas Navigation Variants in HTML/CSS/JS

[Check the demo](https://codepen.io/fox_hover/pen/YgEwbK)
